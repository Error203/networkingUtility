from qlogger import Logger
import argparse
import socket
import time


class WebDog:


	def __init__(self, args):
		self.log = Logger("WebDog Logs").get_logger("WebDog")
		self.args = args
		self.ip = self.args.ip
		self.port = self.args.port
		self.sockets_inspector = dict()

		if not self.ip:
			self.ip = "192.168.0.100"
			self.log.warning("ip is not set. (default: 192.168.0.100)")
		
		if not self.port:
			self.port = 9873
			self.log.warning("port is not set. (default: 9873)")


	def listen(self):
		try:
			self.tcp_listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			self.tcp_listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
			self.tcp_listener.bind((self.ip, self.port))
			self.tcp_listener.listen(1)
			self.log.info(f"tcp listener set up {self.ip}:{self.port}")
			self.sockets_inspector["tcp_listener"] = self.tcp_listener
			self.client, address_info = self.tcp_listener.accept()
			self.log.info(f"caught up connection {address_info[0]}:{address_info[1]}")

		except Exception as e:
			self.log.exception(e)
			self.break_pipe()

			exit(0)

		except (KeyboardInterrupt, EOFError):
			self.break_pipe()
			
			exit(1)


	def communicate(self):
		try:
			self.communicator = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			self.communicator.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
			self.sockets_inspector["tcp_communicator"] = self.communicator
			self.communicator.connect((self.ip, self.port))
			self.log.info(f"connected to {self.ip}:{self.port}")

		except Exception as e:
			self.log.exception(e)
			self.break_pipe()

			exit(0)

		except (KeyboardInterrupt, EOFError):
			self.break_pipe()
			
			exit(1)


	def exchange_headers(self, interlocutor_nickname="interlocutor"):
		try:
			self.nickname = str(input("enter nickname: "))
			if not self.nickname:
				self.nickname = "anonymous"

			if self.args.listen:
				self.log.info("waiting for header")
				self.header_page = self.client.recv(4096).decode("utf-8")
				self.header_page = self.header_page.strip().replace(" ", "").split(";")
				self.log.info("got header page")
				if self.header_page[0] == "DEST.NICKNAME":
					self.interlocutor_nickname = str(self.header_page[1])
				self.header_page = f"DEST.NICKNAME;{self.nickname}".encode("utf-8")
				self.client.send(self.header_page)
				self.log.info("sent header page")

			if not self.args.listen:
				self.header_page = f"DEST.NICKNAME;{self.nickname}".encode("utf-8")
				self.communicator.send(self.header_page)
				self.log.info("sent header page")
				self.log.info("waiting for header")
				self.header_page = self.communicator.recv(4096).decode("utf-8")
				self.header_page = self.header_page.strip().replace(" ", "").split(";")
				self.log.info("got header page")
				if self.header_page[0] == "DEST.NICKNAME":
					self.interlocutor_nickname = str(self.header_page[1])

		except Exception as e:
			self.log.exception(e)
			self.break_pipe()

			exit(0)

		except KeyboardInterrupt:
			print("\n\n")
			self.log.info("got stop signal")
			self.break_pipe()

			exit(1)


	def open_chat(self):
		try:
			data = b""
			data_length = 1

			if self.listen:
				while data_length:
					data += self.tcp_listener.recv(4096)
					data_length = len(data)

				print(data.decode("utf-8"))

			else:
				buffer = b""

				sender_input = input("-> ").encode("utf-8")
				self.communicator.send(sender_input)

		except Exception as e:
			self.log.exception(e)


	def close_chat(self):
		pass


	def break_pipe(self):
		try:
			for i in self.sockets_inspector:
				if self.sockets_inspector[i].fileno() == "-1":
					self.log.warning("connection was broken by another process")

				if self.sockets_inspector[i].fileno() != "-1":
					self.sockets_inspector[i].close()
					self.sockets_inspector[i] = None
					self.log.info("cleaned connection up")

			self.sockets_inspector.clear()

			print("\x07")

		except Exception as e:
			self.log.exception(e)

			exit(0)


if __name__ == '__main__':
	try:
		root_logger = Logger().get_logger("ROOT")

		parser = argparse.ArgumentParser(
			description="WebDog webwork* tool. (netcat analog).",
			epilog="Simple use. Can be used without arguments.",
			)
		parser.add_argument("--ip", type=str, default=None, help="specify an ip address to connect or to listen to.")
		parser.add_argument("--port", type=int, default=None, help="specify a port to connect or to listen to.")
		parser.add_argument("-l", "--listen", action="store_true", help="add this key to listen first (be a server).")
		args = parser.parse_args()

		wd = WebDog(args)
		if args.listen:
			wd.listen()
		else:
			wd.communicate()

		wd.open_chat()

	except Exception as e:
		print(e)
		exit(0)

	finally:
		wd.break_pipe()